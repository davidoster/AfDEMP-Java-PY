
//car object
var car = {

	brand: "Ferrari",
	model: "F430",
	maxSpeed: 330,
	currentSpeed: 0,
	isStarted: false,
	getData() {
		return "Brand: " 	   	 + this.brand 		 + "<br/>" + 
			   "Model: "	   	 + this.model 		 + "<br/>" + 
			   "Maximum Speed: " + this.maxSpeed 	 + "<br/>" + 
			   "Current Speed: " + this.currentSpeed + "<br/>" + 
			   "Has Started: " 	 + this.isStarted 	 + "<br/>";
	},

	start: function () {
		this.isStarted = true;
	},

	setSpeed: function (speed) {
		if(this.isStarted && speed <= this.maxSpeed) {
			this.currentSpeed = speed;
		}
		
	},

	stop: function() {
		if(this.currentSpeed == 0) {
			this.isStarted = false;
		}
		
		
	}

}

//Functions that edit the object.
function showData() {
	document.getElementById("carData").innerHTML = car.getData();
}

function start() {
	car.start();
	showData();
}

function stop() {
	car.stop();
	showData();
}

function setSpeed() {
	var value = document.getElementById("carSpeed").value;
	if(isNaN(value)) {
		value = 0;
	}
	car.setSpeed(value);
	showData();
}



