function strConcat(str1, str2) {
	var result = str1 + str2;
	return result; //can also directly return str1 + str2;
}

alert(strConcat("Hello ", "World!"));

//A more "advanced example".
//Same as "This " + "Is " + "John!";
alert(strConcat("This ", strConcat("Is ", "John!")));
