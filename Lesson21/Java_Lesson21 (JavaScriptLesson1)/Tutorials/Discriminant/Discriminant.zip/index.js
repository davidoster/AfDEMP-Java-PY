function get2DegreePolynomialDiscriminant(a, b, c) {
	return (b*b) - (4*a*c);
}

alert(get2DegreePolynomialDiscriminant(1, 4, 3));