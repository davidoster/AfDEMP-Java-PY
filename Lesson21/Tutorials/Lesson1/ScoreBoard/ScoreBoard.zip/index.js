
//car object
var scoreBoard = {

	homeScore: 0,
	awayScore: 0,
	minutePlaying: 0,

	setHomeScore: function (score) {
		this.homeScore = score;
	},

	setAwayScore: function (score) {
		this.awayScore = score;
	},

	setMinutePlaying: function (minutePlaying) {
		this.minutePlaying = minutePlaying;
	},

	getDisplay: function() {
		return this.minutePlaying + "': Home:" + this.homeScore + " - Away:" + this.awayScore; 
	}
}

scoreBoard.setHomeScore(1);
scoreBoard.setAwayScore(2);
scoreBoard.setMinutePlaying(50);

alert(scoreBoard.getDisplay());



