console.log(2 + 3); //5
console.log("Hello " + "World!"); //Hello World!
console.log("Hello " + 1); //Hello1
console.log("Hello" * 5) //NaN
console.log("Hello" / 2) //NaN
console.log(10/0); //Infinity