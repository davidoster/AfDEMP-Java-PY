/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise1;

import java.util.Arrays;

/**
 *
 * @author smavros
 */
public class FirstDayAtSchool {
    public String[] prepareMyBag(){
		String[] schoolbag = {"Books", "Notebooks", "Pens"};
		System.out.println("My school bag contains: " + Arrays.toString(schoolbag));
		return schoolbag;
	}
	
	public String[] addPencils(){
		String[] schoolbag = {"Books", "Notebooks", "Pens", "Pencils"};
		System.out.println("Now my school bag contains: " + Arrays.toString(schoolbag));
		return schoolbag;
	}
    
}
