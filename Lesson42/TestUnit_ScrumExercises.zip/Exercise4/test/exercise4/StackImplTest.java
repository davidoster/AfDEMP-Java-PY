/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise4;

import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Spyros
 */
public class StackImplTest {

    private Stack testStack;

    public StackImplTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        testStack = new StackImpl();
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of isEmpty method, of class StackImpl.
     */
    @Test
    public void testIsEmpty() {

    }

    /**
     * Test of makeEmpty method, of class StackImpl.
     */
    @Test
    public void testMakeEmpty() {
        testStack = new StackImpl();
        testStack.push(new Integer(3));
        testStack.push(new Integer(4));
        testStack.makeEmpty();
        assertEquals(0, testStack.size());
    }

    /**
     * Test of push method, of class StackImpl.
     */
    @Test
    public void testPush() {

    }

    /**
     * Test of pop method, of class StackImpl.
     */
    @Test
    public void testPop() {

    }

    /**
     * Test of top method, of class StackImpl.
     */
    @Test
    public void testTop() {

    }

    /**
     * Test of size method, of class StackImpl.
     */
    @Test
    public void testSize() {

    }

    /**
     * Test of toString method, of class StackImpl.
     */
    @Test
    public void testToString() {

    }

}
