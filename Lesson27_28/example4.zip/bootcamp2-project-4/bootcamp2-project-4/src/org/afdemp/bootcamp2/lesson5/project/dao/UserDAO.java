package org.afdemp.bootcamp2.lesson5.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.afdemp.bootcamp2.lesson5.project.connection.DB;
import org.afdemp.bootcamp2.lesson5.project.domain.User;

public class UserDAO {

	public UserDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public User authenticateUser (String username, String password) throws Exception {

		Connection con = null;
		DB db = new DB();
		
		
		/* Task 1 */
		
		
		
	} //End of authenticateUser
	
} //End of class
