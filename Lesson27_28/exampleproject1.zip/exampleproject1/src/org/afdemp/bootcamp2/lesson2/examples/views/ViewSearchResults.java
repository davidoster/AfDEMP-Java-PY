package org.afdemp.bootcamp2.lesson2.examples.views;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.afdemp.bootcamp2.lesson2.examples.model.Employee;

/**
 * Servlet implementation class ViewSearchResults
 */
@WebServlet("/viewresults")
public class ViewSearchResults extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ViewSearchResults() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");

		ArrayList<Employee> resultlist = (ArrayList<Employee>) request.getAttribute("employee-list");

		PrintWriter out = new PrintWriter(response.getWriter());

		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("    <head>");
		out.println("        <meta charset='utf-8'>");
		out.println("        <meta http-equiv='X-UA-Compatible' content='IE=edge'>");
		out.println("        <meta name='viewport' content='width=device-width, initial-scale=1'>");
		out.println(
				"        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->");
		out.println("        <title>������������ ����������</title>");
		out.println("        <!-- Bootstrap core CSS -->");
		out.println(
				"        <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
		out.println("        <!-- Example custom style -->");
		out.println("		<link rel='stylesheet' href='css/customstyle.css'>");
		out.println("        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->");
		out.println("        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->");
		out.println("        <!--[if lt IE 9]>");
		out.println("          <script src='https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js'></script>");
		out.println("          <script src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js'></script>");
		out.println("        <![endif]-->");
		out.println("    </head>");
		out.println("    <body>");
		out.println("      <div class='container'>");
		out.println("      	<div class='page-header'>");
		out.println("        	<h1 class='text-center'>������������ ���������� ");
		
		if (resultlist != null && resultlist.size() > 0) {
			out.println("        	<span class='badge'>" + resultlist.size() + "</span>");
		}
		
		out.println("        	</h1>");		
		out.println("       </div>");
		out.println("        <div class='row'");
		out.println("          <div class='col-xs-12'>");
		out.println("          		<div class='table-responsive'>");
		out.println("            		<table class='table table-striped table-bordered table-hover table-condensed'>");
		out.println("              			<tr class='warning'>");
		out.println("              				<th>���</th><th>�����</th><th>�������</th>");
		out.println("              			</tr>");

		if (resultlist == null || resultlist.size() == 0) {

			out.println("              			<tr>");
			out.println("              				<td colspan='3' class='bg-danger text-center'>No results found using: '<b>" 
								+ request.getParameter("surname")  +"</b>'</td>");
			out.println("              			</tr>");

		} else {

			for (Employee employee : resultlist) {
				out.println("              			<tr>");
				out.println("              				<td>" + employee.getAfm() + "</td>" + "<td>"
						+ employee.getName() + "</td>" + "<td>" + employee.getSurname() + "</td>");
				out.println("              			</tr>");
			}

		}

		out.println("          			</table>");
		out.println("          		</div>");
		out.println("          </div>");
		out.println("        </div>");
		out.println("      </div><!-- /.container -->");
		out.println("      <!-- JavaScript files before the closing body tag -->");
		out.println("      <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>");
		out.println(
				"      <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
		out.println("  </body>");
		out.println("</html>");

	}

}
