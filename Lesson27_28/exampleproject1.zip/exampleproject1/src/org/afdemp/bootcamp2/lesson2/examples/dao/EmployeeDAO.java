/**
 * 
 */
package org.afdemp.bootcamp2.lesson2.examples.dao;

import java.util.ArrayList;
import java.util.Locale;

import org.afdemp.bootcamp2.lesson2.examples.model.Employee;

/**
 * 
 *
 */
public class EmployeeDAO {
	
	/**
	 * Default Constructor 
	 */
	public EmployeeDAO() {
		// TODO Auto-generated constructor stub
	}	
	
	/**
	 * This method normally will connect to Database (ex via JDBC) and search to find the employees by executing a query.
	 * But, in this example, we "simulate" and return an ArrayList of Employee objects (using dummy data in both English and Greek)  
	 * In the following Lessons we will see how to connect to a database via JDBC, execute queries and fetch real data. 
	 * 
	 * @param surname
	 * @return
	 */
	public ArrayList<Employee> findEmployeeBySurname(String surname) {
		
		ArrayList<Employee> results = new ArrayList<Employee>();
		
		/*
		 * A convenient way to loop each Employee object of the ArrayList
		 */
		for(Employee employee : allEmployees) {
			
			/*
			 * We could use in the if the condition: employee.getSurname().equals(surname)
			 * if we wanted to demand from the user to type exactly the surname of the employee.
			 * In this example we want user to be able to type a part of surname (or whole).   
			 */
			
			if( employee.getSurname().toUpperCase().startsWith(surname.toUpperCase()) )  {
				results.add(employee);
			}
			
		}
		
		return results;
		
	}
	
	private ArrayList<Employee> allEmployees = new ArrayList<Employee>() {
	    {
	    	add(new Employee("113456789", "����������", "��������"));
			add(new Employee("123456789", "�����", "�������"));
			add(new Employee("133456789", "�������", "��������"));
			add(new Employee("143456789", "��������", "���������"));
			add(new Employee("153456789", "�������", "���������"));
			add(new Employee("163456789", "�������", "���������"));
			add(new Employee("173456789", "John", "Doe"));
			add(new Employee("183456789", "Jane", "Doe"));
			add(new Employee("193456789", "Mark", "Doe"));
			add(new Employee("191456789", "Jim", "Smith"));
			add(new Employee("192456789", "Mary", "Evans"));
	    }
	};

}
