public class MyDB {

   public static void main(String[] args) {
     
     int a[] = new int[] {-1,1,3,5,7,9};
     for (int i = 0; i < a.length; i++) {
     	if( a[i] == 3 ) {
            break;
         }else
          System.out.print(a[i] + ", "); 
   		}
	}

}