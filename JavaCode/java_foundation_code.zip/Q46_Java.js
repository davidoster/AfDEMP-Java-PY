class AB{
	public void Display(){
	System.out.println("AB::Display");
	}
}

class DA extends AB{
 
  public void Display(){
        System.out.println("DA::Display");
    }
}
         
public class sample{
    public static void main(String args[])
    {
    AB b;
	b = new AB();
	b.Display();
   	b = new DA();
	b.Display();  
    }
}  