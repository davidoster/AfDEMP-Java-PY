public class MyTest {

    private static int x;

    public static void setX(int x1) {
        x = x1;
    }

    public static int getX() {
        return x;
    }

public static void main(String[] args) {
 	    System.out.println("Output: " + x);
    }
}

