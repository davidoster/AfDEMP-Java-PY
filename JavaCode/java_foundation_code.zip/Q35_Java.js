import java.util.Scanner;
 
abstract class calcArea {
    abstract void findSquare(int s);
    abstract void findCircle(double r);
}
 
class findArea extends calcArea {
 
    void findSquare(int s)
    {
        int area = s*s;
        System.out.println("Area of Square: "+area);
    }
     
    void findCircle(double r)
    {
        double area = 3.14*r*r;
        System.out.println("Area of Circle: "+area);
    }
}
         
public class area {
    public static void main(String args[])
    {
        int l, b, h, r, s;
        findArea area = new findArea();
        Scanner get = new Scanner(System.in);
 
        s = 15;
        area.findSquare(s);
     
    }
}   