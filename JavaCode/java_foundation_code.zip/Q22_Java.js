public class MyTest {

   public static void main(String[] args) {
     int x = 100;
     int z = 100;
     x++;
     z = (x + 1);
     
     System.out.println("x is " + x + " and z is " + z); 
     
     x = 100;
     x++;
     z = x;
     
     System.out.println("x is " + x + " and z is " + z);  
   }
}
