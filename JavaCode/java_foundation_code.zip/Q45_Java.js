public class MyTest{
	public static void main(String args[]) {
    int i;
    int[] a = new int[8];
      for (i = 1; i <= 7 ; i++) {
        a[i] = i+2;
    }
    System.out.println(a[2]);
	}  
}