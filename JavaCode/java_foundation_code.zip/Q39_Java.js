boolean valid = true;
while (valid){
  System.out.println("Hello world!");
}