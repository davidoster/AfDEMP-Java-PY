public class MyDB {

   public static void main(String[] args) {
     
     int a[] = new int[] {1,2,3,4,5};
     System.out.println("a[ " + a[6] + ",");  
   }
}
