/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringvsstringbuilder;

/**
 *
 * @author Spyros
 */
public class StringVSStringBuilder {

    public static String repeat1(char c, int n) {
        long starttime = System.currentTimeMillis();
        String answer = "";
        for (int j = 0; j < n; j++) {
            answer += c;
        }
        long endtime = System.currentTimeMillis();
        long elapsed = endtime - starttime;
        System.out.println("String " + elapsed);
        return answer;
    }

    public static String repeat2(char c, int n) {
        long starttime = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < n; j++) {
            sb.append(c);
        }
        long endtime = System.currentTimeMillis();
        long elapsed = endtime - starttime;
        System.out.println("StringBuilder " + elapsed);
        return sb.toString();
    }

    public static void main(String[] args) {
        //repeat1('s', 10000);
        //repeat2('s', 1000000);
    }

}
