/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.Arrays;

/**
 *
 * @author Spyros
 */
public class Sorting {

    public static void insertionSort(char[] data) {
        int n = data.length;
        for (int k = 1; k < n; k++) { // begin with second character
            char cur = data[k]; // time to insert cur=data[k]
            int j = k; // find correct index j for cur
            while (j > 0 && data[j - 1] > cur) { // thus, data[j-1] must go after cur
                data[j] = data[j - 1]; // slide data[j-1] rightward
                j--; // and consider previous j for cur
            }
            data[j] = cur; // this is the proper place for cur
        }
    }

    public static void bubble_sort(int a[]) {
        int temp;
        int n = a.length;
        for (int k = 0; k < n - 1; k++) {
            // (n-k-1) is for ignoring comparisons of elements which have already been compared in earlier iterations
            for (int i = 0; i < n - k - 1; i++) {
                if (a[i] > a[i + 1]) {
                    // here swapping of positions is being done.
                    temp = a[i];
                    a[i] = a[i + 1];
                    a[i + 1] = temp;
                }
            }
        }
    }

    // Bucket sort
    public static void bucketsort(int[] a, int maxVal) {
        int[] bucket = new int[maxVal + 1];

        for (int i = 0; i < bucket.length; i++) {
            bucket[i] = 0;
        }

        for (int i = 0; i < a.length; i++) {
            bucket[a[i]]++;
        }

        int outPos = 0;
        for (int i = 0; i < bucket.length; i++) {
            for (int j = 0; j < bucket[i]; j++) {
                a[outPos++] = i;
            }
        }
    }

    public static void main(String[] args) {
        //Inserion sort
//        char[] myarray = {'d', 'e', 'a', 'n', 'z'};
//        System.out.println(Arrays.toString(myarray));
//        insertionSort(myarray);
//        System.out.println(Arrays.toString(myarray));
        // Arrays.sort(myarray) uses quicksort on primitives and mergesort on Objects (like Collection.sort)

        // Bubble sort
//        int[] myarray1 = {4, 2, 8, 55, 6, 34, 99, 67};
//        System.out.println(Arrays.toString(myarray1));
//        bubble_sort(myarray1);
//        System.out.println(Arrays.toString(myarray1));
        // Merge sort
        int[] inputArr = {45, 23, 11, 89, 77, 98, 4, 28, 65, 43};
//        MyMergeSort mms = new MyMergeSort();
//        mms.mergesort(inputArr);
//        System.out.println(Arrays.toString(inputArr));

        int[] inputArr1 = {5, 3, 0, 2, 4, 1, 0, 5, 2, 3, 1, 4};
        System.out.println(Arrays.toString(inputArr1));
        bucketsort(inputArr1, 5);
        System.out.println(Arrays.toString(inputArr1));
    }

}
