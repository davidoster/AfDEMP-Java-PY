// boilerplate for any jQuery
$(document).ready(function(){  // do not delete 
// ----------------------------------------------------------------------------


// put all jQuery in here, and it will execute after the HTML page 
// has completely loaded 



// ----------------------------------------------------------------------------
}); // do not delete; closes (document).ready function 
